using UnityEngine;

public class SimplePlayerMovement : MonoBehaviour
{
    public float speed = 5f;                 // Movement speed
    public float mouseSensitivity = 100f;   // Mouse sensitivity
    public Transform playerCamera;           // Assign the child Camera here

    float xRotation = 0f;

    void Start()
    {
        // Lock cursor and hide it at start
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    void Update()
    {
        // Press Escape to toggle cursor lock/unlock
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (Cursor.lockState == CursorLockMode.Locked)
            {
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;
            }
            else
            {
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible = false;
            }
        }

        // Only allow movement and look if cursor is locked
        if (Cursor.lockState == CursorLockMode.Locked)
        {
            // Mouse look
            float mouseX = Input.GetAxis("Mouse X") * mouseSensitivity * Time.deltaTime;
            float mouseY = Input.GetAxis("Mouse Y") * mouseSensitivity * Time.deltaTime;

            xRotation -= mouseY;
            xRotation = Mathf.Clamp(xRotation, -90f, 90f);

            playerCamera.localRotation = Quaternion.Euler(xRotation, 0f, 0f);
            transform.Rotate(Vector3.up * mouseX);

            // Movement input
            float moveX = Input.GetAxis("Horizontal"); // A, D or Left/Right arrows
            float moveZ = Input.GetAxis("Vertical");   // W, S or Up/Down arrows

            Vector3 move = transform.right * moveX + transform.forward * moveZ;
            transform.position += move * speed * Time.deltaTime;
        }
    }
}
