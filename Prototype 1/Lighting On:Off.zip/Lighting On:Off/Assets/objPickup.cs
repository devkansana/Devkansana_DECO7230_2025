using UnityEngine;

public class PickUp : MonoBehaviour
{
    public Transform playerCamera;      // Assign main camera transform in Inspector
    private bool isPickedUp = false;
    private Transform originalParent;
    private float pickUpDistance = 3f;

    private float rotationSpeed = 5f; // Adjust this for sensitivity

    void Start()
    {
        if (playerCamera == null)
        {
            Debug.LogError("Player Camera not assigned in the inspector");
        }
        originalParent = transform.parent;
    }

    void Update()
    {
        // On left mouse button click
        if (Input.GetMouseButtonDown(0))
        {
            if (!isPickedUp)
            {
                TryPickUp();
            }
            else
            {
                Drop();
            }
        }

        if (isPickedUp)
        {
            RotatePickedUpObject();
        }
    }

    void TryPickUp()
    {
        if (playerCamera == null) return;

        Ray ray = playerCamera.GetComponent<Camera>().ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;

        if (Physics.Raycast(ray, out hit, pickUpDistance))
        {
            if (hit.transform == this.transform)
            {
                isPickedUp = true;
                transform.SetParent(playerCamera);
                transform.localPosition = new Vector3(0, 0, 2);
                Rigidbody rb = GetComponent<Rigidbody>();
                if (rb != null)
                    rb.isKinematic = true;
            }
        }
    }

    void Drop()
    {
        isPickedUp = false;
        transform.SetParent(originalParent);
        Rigidbody rb = GetComponent<Rigidbody>();
        if (rb != null)
            rb.isKinematic = false;
    }

    void RotatePickedUpObject()
    {
        // Hold right mouse and move to rotate
        if (Input.GetMouseButton(1)) // Right mouse button held
        {
            float rotX = Input.GetAxis("Mouse X") * rotationSpeed;
            float rotY = Input.GetAxis("Mouse Y") * rotationSpeed;

            transform.Rotate(playerCamera.up, -rotX, Space.World);
            transform.Rotate(playerCamera.right, rotY, Space.World);
        }
    }
}
